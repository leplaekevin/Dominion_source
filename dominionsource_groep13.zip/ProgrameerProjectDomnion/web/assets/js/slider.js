$(document).ready(function(){
  $('.slider1').bxSlider({
    slideWidth: 200,
    minSlides: 5,
    maxSlides: 5,
    slideMargin: 10
  });
});