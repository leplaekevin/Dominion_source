/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProgrameerProjectDominion;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Pc_Kevin
 */



@RunWith(Suite.class)
@Suite.SuiteClasses({ProgrameerProjectDominion.TestDeck.class,ProgrameerProjectDominion.TestDominion.class,
    ProgrameerProjectDominion.TestKaart.class,ProgrameerProjectDominion.TestSpeler.class,})
public class TestSuiteDominion   {

    
}
